const cds = require('@sap/cds');

module.exports = cds.service.impl(async function() {
    
    // Helper to get and validate user
    const getAuthenticatedEmployee = async (req) => {
        const userId = req.user.id;
        
        if (!userId) {
            req.error(401, 'User not authenticated');
            return null;
        }

        const employee = await SELECT.one.from('my.timesheet.Employees')
            .where({ ID: userId, isActive: true });

        if (!employee) {
            req.error(404, 'Employee profile not found or inactive. Please contact administrator.');
            return null;
        }

        return employee;
    };

    // ✅ NEW: Helper to get week boundaries (Monday to Sunday)
    const getWeekBoundaries = (date) => {
        const inputDate = new Date(date);
        const dayOfWeek = inputDate.getDay(); // 0 = Sunday, 1 = Monday, ..., 6 = Saturday
        
        // Calculate Monday (start of week)
        const monday = new Date(inputDate);
        const daysToMonday = dayOfWeek === 0 ? -6 : 1 - dayOfWeek; // If Sunday, go back 6 days
        monday.setDate(inputDate.getDate() + daysToMonday);
        monday.setHours(0, 0, 0, 0);
        
        // Calculate Sunday (end of week)
        const sunday = new Date(monday);
        sunday.setDate(monday.getDate() + 6);
        sunday.setHours(23, 59, 59, 999);
        
        return {
            weekStart: monday.toISOString().split('T')[0],
            weekEnd: sunday.toISOString().split('T')[0]
        };
    };

    // ✅ NEW: Helper to get all 7 days of the week with day names
    const getWeekDates = (weekStart) => {
        const monday = new Date(weekStart);
        const days = [];
        const dayNames = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        
        for (let i = 0; i < 7; i++) {
            const date = new Date(monday);
            date.setDate(monday.getDate() + i);
            days.push({
                date: date.toISOString().split('T')[0],
                day: dayNames[i]
            });
        }
        
        return days;
    };

// ✅ UPDATED: Before CREATE - Validate and prepare weekly batch entry with daily task details
    this.before('CREATE', 'MyTimesheets', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return;

        const employeeID = employee.ID;
        const { task, project_ID, activity_ID, nonProjectType_ID, isBillable } = req.data;

        // Validate task type
        const validTasks = ['Designing', 'Developing', 'Testing', 'Bug Fix', 'Deployment', 'Client Call', 'Leave'];
        if (task && !validTasks.includes(task)) {
            return req.error(400, `Invalid task type. Must be one of: ${validTasks.join(', ')}`);
        }

        // Calculate week boundaries from any provided date field
        let referenceDate = req.data.weekStartDate || req.data.mondayDate || new Date().toISOString().split('T')[0];
        const weekBoundaries = getWeekBoundaries(referenceDate);
        const weekDates = getWeekDates(weekBoundaries.weekStart);

        // Set week dates
        req.data.weekStartDate = weekBoundaries.weekStart;
        req.data.weekEndDate = weekBoundaries.weekEnd;

        // Set individual day dates and day names
        req.data.mondayDate = weekDates[0].date;
        req.data.mondayDay = weekDates[0].day;
        req.data.tuesdayDate = weekDates[1].date;
        req.data.tuesdayDay = weekDates[1].day;
        req.data.wednesdayDate = weekDates[2].date;
        req.data.wednesdayDay = weekDates[2].day;
        req.data.thursdayDate = weekDates[3].date;
        req.data.thursdayDay = weekDates[3].day;
        req.data.fridayDate = weekDates[4].date;
        req.data.fridayDay = weekDates[4].day;
        req.data.saturdayDate = weekDates[5].date;
        req.data.saturdayDay = weekDates[5].day;
        req.data.sundayDate = weekDates[6].date;
        req.data.sundayDay = weekDates[6].day;

        // Ensure all day hours default to 0 if not provided
        req.data.mondayHours = req.data.mondayHours || 0;
        req.data.tuesdayHours = req.data.tuesdayHours || 0;
        req.data.wednesdayHours = req.data.wednesdayHours || 0;
        req.data.thursdayHours = req.data.thursdayHours || 0;
        req.data.fridayHours = req.data.fridayHours || 0;
        req.data.saturdayHours = req.data.saturdayHours || 0;
        req.data.sundayHours = req.data.sundayHours || 0;

        // ✅ NEW: Ensure all daily task details default to empty string if not provided
        req.data.mondayTaskDetails = req.data.mondayTaskDetails || '';
        req.data.tuesdayTaskDetails = req.data.tuesdayTaskDetails || '';
        req.data.wednesdayTaskDetails = req.data.wednesdayTaskDetails || '';
        req.data.thursdayTaskDetails = req.data.thursdayTaskDetails || '';
        req.data.fridayTaskDetails = req.data.fridayTaskDetails || '';
        req.data.saturdayTaskDetails = req.data.saturdayTaskDetails || '';
        req.data.sundayTaskDetails = req.data.sundayTaskDetails || '';

        // Calculate total week hours
        req.data.totalWeekHours = 
            parseFloat(req.data.mondayHours || 0) +
            parseFloat(req.data.tuesdayHours || 0) +
            parseFloat(req.data.wednesdayHours || 0) +
            parseFloat(req.data.thursdayHours || 0) +
            parseFloat(req.data.fridayHours || 0) +
            parseFloat(req.data.saturdayHours || 0) +
            parseFloat(req.data.sundayHours || 0);

        // Validate: Each day cannot exceed 15 hours
        const dailyHours = [
            { day: 'Monday', hours: req.data.mondayHours },
            { day: 'Tuesday', hours: req.data.tuesdayHours },
            { day: 'Wednesday', hours: req.data.wednesdayHours },
            { day: 'Thursday', hours: req.data.thursdayHours },
            { day: 'Friday', hours: req.data.fridayHours },
            { day: 'Saturday', hours: req.data.saturdayHours },
            { day: 'Sunday', hours: req.data.sundayHours }
        ];

        for (const day of dailyHours) {
            if (day.hours > 15) {
                return req.error(400, `${day.day} hours cannot exceed 15. Current: ${day.hours}`);
            }
        }

        // ✅ NEW: Validate that if hours are entered for a day, task details should be provided
        const dailyData = [
            { day: 'Monday', hours: req.data.mondayHours, details: req.data.mondayTaskDetails },
            { day: 'Tuesday', hours: req.data.tuesdayHours, details: req.data.tuesdayTaskDetails },
            { day: 'Wednesday', hours: req.data.wednesdayHours, details: req.data.wednesdayTaskDetails },
            { day: 'Thursday', hours: req.data.thursdayHours, details: req.data.thursdayTaskDetails },
            { day: 'Friday', hours: req.data.fridayHours, details: req.data.fridayTaskDetails },
            { day: 'Saturday', hours: req.data.saturdayHours, details: req.data.saturdayTaskDetails },
            { day: 'Sunday', hours: req.data.sundayHours, details: req.data.sundayTaskDetails }
        ];

        for (const dayData of dailyData) {
            if (dayData.hours > 0 && (!dayData.details || dayData.details.trim() === '')) {
                return req.error(400, `${dayData.day}: Task details are required when hours are entered.`);
            }
        }

        // Validate: Check for duplicate entries (same employee, project, task, week)
        const existing = await SELECT.from('my.timesheet.Timesheets')
            .where({ 
                employee_ID: employeeID, 
                project_ID: project_ID || null,
                task: task,
                weekStartDate: weekBoundaries.weekStart
            });

        if (existing.length > 0) {
            return req.error(400, `A timesheet entry for this project/task already exists for week starting ${weekBoundaries.weekStart}. Please update the existing entry instead.`);
        }

        // Validate activity exists if provided
        if (activity_ID) {
            const activity = await SELECT.one.from('my.timesheet.Activities').where({ ID: activity_ID });
            if (!activity) {
                return req.error(404, 'Activity not found');
            }
            if (activity.status !== 'Active') {
                return req.error(400, 'This activity is not active');
            }
            req.data.project_ID = activity.project_ID || null;
        }

        // Validate non-project type exists if provided
        if (nonProjectType_ID) {
            const nonProjectType = await SELECT.one.from('my.timesheet.NonProjectTypes').where({ ID: nonProjectType_ID });
            if (!nonProjectType) {
                return req.error(404, 'Non-Project Type not found');
            }
            if (!nonProjectType.isActive) {
                return req.error(400, 'This non-project type is not active');
            }
        }

        req.data.employee_ID = employeeID;
        req.data.status = req.data.status || 'Draft';
    });

    // ✅ CHANGED: After CREATE - Generate timesheet ID
    this.after('CREATE', 'MyTimesheets', async (data, req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return;
        
        const employeeID = employee.ID;
        const count = await SELECT.from('my.timesheet.Timesheets').where({ employee_ID: employeeID });
        const timesheetID = `TS${String(count.length).padStart(4, '0')}`;
        await UPDATE('my.timesheet.Timesheets').set({ timesheetID }).where({ ID: data.ID });
    });

   // ✅ UPDATED: Before UPDATE - Recalculate total hours and validate daily task details
    this.before('UPDATE', 'MyTimesheets', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return;

        const timesheetInternalID = req.data.ID;
        if (!timesheetInternalID) return;

        const timesheet = await SELECT.one.from('my.timesheet.Timesheets').where({ ID: timesheetInternalID });

        if (!timesheet) {
            return req.error(404, 'Timesheet not found');
        }

        if (timesheet.employee_ID !== employee.ID) {
            return req.error(403, 'You can only update your own timesheets');
        }

        // Recalculate total if any day hours changed
        if (req.data.mondayHours !== undefined || req.data.tuesdayHours !== undefined ||
            req.data.wednesdayHours !== undefined || req.data.thursdayHours !== undefined ||
            req.data.fridayHours !== undefined || req.data.saturdayHours !== undefined ||
            req.data.sundayHours !== undefined) {
            
            req.data.totalWeekHours = 
                parseFloat(req.data.mondayHours !== undefined ? req.data.mondayHours : timesheet.mondayHours || 0) +
                parseFloat(req.data.tuesdayHours !== undefined ? req.data.tuesdayHours : timesheet.tuesdayHours || 0) +
                parseFloat(req.data.wednesdayHours !== undefined ? req.data.wednesdayHours : timesheet.wednesdayHours || 0) +
                parseFloat(req.data.thursdayHours !== undefined ? req.data.thursdayHours : timesheet.thursdayHours || 0) +
                parseFloat(req.data.fridayHours !== undefined ? req.data.fridayHours : timesheet.fridayHours || 0) +
                parseFloat(req.data.saturdayHours !== undefined ? req.data.saturdayHours : timesheet.saturdayHours || 0) +
                parseFloat(req.data.sundayHours !== undefined ? req.data.sundayHours : timesheet.sundayHours || 0);

            // Validate each day doesn't exceed 15 hours
            const hoursToCheck = [
                { day: 'Monday', hours: req.data.mondayHours !== undefined ? req.data.mondayHours : timesheet.mondayHours },
                { day: 'Tuesday', hours: req.data.tuesdayHours !== undefined ? req.data.tuesdayHours : timesheet.tuesdayHours },
                { day: 'Wednesday', hours: req.data.wednesdayHours !== undefined ? req.data.wednesdayHours : timesheet.wednesdayHours },
                { day: 'Thursday', hours: req.data.thursdayHours !== undefined ? req.data.thursdayHours : timesheet.thursdayHours },
                { day: 'Friday', hours: req.data.fridayHours !== undefined ? req.data.fridayHours : timesheet.fridayHours },
                { day: 'Saturday', hours: req.data.saturdayHours !== undefined ? req.data.saturdayHours : timesheet.saturdayHours },
                { day: 'Sunday', hours: req.data.sundayHours !== undefined ? req.data.sundayHours : timesheet.sundayHours }
            ];

            for (const day of hoursToCheck) {
                if (day.hours > 15) {
                    return req.error(400, `${day.day} hours cannot exceed 15.`);
                }
            }
        }

        // ✅ NEW: Validate that if hours are updated for a day, task details should be provided
        const dailyValidations = [
            { 
                day: 'Monday', 
                hours: req.data.mondayHours !== undefined ? req.data.mondayHours : timesheet.mondayHours,
                details: req.data.mondayTaskDetails !== undefined ? req.data.mondayTaskDetails : timesheet.mondayTaskDetails
            },
            { 
                day: 'Tuesday', 
                hours: req.data.tuesdayHours !== undefined ? req.data.tuesdayHours : timesheet.tuesdayHours,
                details: req.data.tuesdayTaskDetails !== undefined ? req.data.tuesdayTaskDetails : timesheet.tuesdayTaskDetails
            },
            { 
                day: 'Wednesday', 
                hours: req.data.wednesdayHours !== undefined ? req.data.wednesdayHours : timesheet.wednesdayHours,
                details: req.data.wednesdayTaskDetails !== undefined ? req.data.wednesdayTaskDetails : timesheet.wednesdayTaskDetails
            },
            { 
                day: 'Thursday', 
                hours: req.data.thursdayHours !== undefined ? req.data.thursdayHours : timesheet.thursdayHours,
                details: req.data.thursdayTaskDetails !== undefined ? req.data.thursdayTaskDetails : timesheet.thursdayTaskDetails
            },
            { 
                day: 'Friday', 
                hours: req.data.fridayHours !== undefined ? req.data.fridayHours : timesheet.fridayHours,
                details: req.data.fridayTaskDetails !== undefined ? req.data.fridayTaskDetails : timesheet.fridayTaskDetails
            },
            { 
                day: 'Saturday', 
                hours: req.data.saturdayHours !== undefined ? req.data.saturdayHours : timesheet.saturdayHours,
                details: req.data.saturdayTaskDetails !== undefined ? req.data.saturdayTaskDetails : timesheet.saturdayTaskDetails
            },
            { 
                day: 'Sunday', 
                hours: req.data.sundayHours !== undefined ? req.data.sundayHours : timesheet.sundayHours,
                details: req.data.sundayTaskDetails !== undefined ? req.data.sundayTaskDetails : timesheet.sundayTaskDetails
            }
        ];

        for (const validation of dailyValidations) {
            if (validation.hours > 0 && (!validation.details || validation.details.trim() === '')) {
                return req.error(400, `${validation.day}: Task details are required when hours are entered.`);
            }
        }

        if (timesheet.status === 'Approved') {
            req.data.status = 'Modified';
        }
    });

    // After UPDATE - Send notifications
    this.after('UPDATE', 'MyTimesheets', async (data, req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return;

        const timesheet = await SELECT.one.from('my.timesheet.Timesheets')
            .where({ ID: data.ID });

        if (timesheet && timesheet.status === 'Modified') {
            const notificationCount = await SELECT.from('my.timesheet.Notifications');
            
            if (employee.managerID_ID) {
                await INSERT.into('my.timesheet.Notifications').entries({
                    notificationID: `NOT${String(notificationCount.length + 1).padStart(4, '0')}`,
                    recipient_ID: employee.managerID_ID,
                    message: `${employee.firstName} ${employee.lastName} modified previously approved timesheet for week ${timesheet.weekStartDate}`,
                    notificationType: 'Timesheet Modified',
                    isRead: false,
                    relatedEntity: 'Timesheet',
                    relatedEntityID: timesheet.ID
                });
            }
        }
    });

    // ✅ NEW: Function to get week boundaries
    this.on('getWeekBoundaries', async (req) => {
        const { date } = req.data;
        return getWeekBoundaries(date);
    });

    // ✅ NEW: Function to validate daily hours for a specific date
    this.on('validateDailyHours', async (req) => {
        const { date } = req.data;
        
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return 0;
        
        const employeeID = employee.ID;
        const weekBoundaries = getWeekBoundaries(date);

        // Get all timesheets for this week
        const timesheets = await SELECT.from('my.timesheet.Timesheets')
            .where({ employee_ID: employeeID, weekStartDate: weekBoundaries.weekStart });
       
        // Determine which day of the week the date is
        const targetDate = new Date(date);
        const dayOfWeek = targetDate.getDay(); // 0 = Sunday, 1 = Monday, etc.
        
        let totalHours = 0;
        for (const ts of timesheets) {
            switch(dayOfWeek) {
                case 1: totalHours += parseFloat(ts.mondayHours || 0); break;
                case 2: totalHours += parseFloat(ts.tuesdayHours || 0); break;
                case 3: totalHours += parseFloat(ts.wednesdayHours || 0); break;
                case 4: totalHours += parseFloat(ts.thursdayHours || 0); break;
                case 5: totalHours += parseFloat(ts.fridayHours || 0); break;
                case 6: totalHours += parseFloat(ts.saturdayHours || 0); break;
                case 0: totalHours += parseFloat(ts.sundayHours || 0); break;
            }
        }

        return totalHours;
    });

    // Action: Submit Timesheet
    this.on('submitTimesheet', async (req) => {
        const { timesheetID } = req.data;
        
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return 'Employee not found';
        
        const employeeID = employee.ID;

        const timesheet = await SELECT.one.from('my.timesheet.Timesheets')
            .where({ timesheetID, employee_ID: employeeID });

        if (!timesheet) {
            return req.error(404, 'Timesheet not found');
        }

        if (timesheet.status !== 'Draft' && timesheet.status !== 'Modified') {
            return req.error(400, 'Only draft or modified timesheets can be submitted');
        }

        await UPDATE('my.timesheet.Timesheets').set({ status: 'Submitted' }).where({ ID: timesheet.ID });

        if (employee.managerID_ID) {
            const notificationCount = await SELECT.from('my.timesheet.Notifications');
            await INSERT.into('my.timesheet.Notifications').entries({
                notificationID: `NOT${String(notificationCount.length + 1).padStart(4, '0')}`,
                recipient_ID: employee.managerID_ID,
                message: `${employee.firstName} ${employee.lastName} submitted timesheet for week ${timesheet.weekStartDate}`,
                notificationType: 'Timesheet Submission',
                isRead: false,
                relatedEntity: 'Timesheet',
                relatedEntityID: timesheet.ID
            });
        }

        return 'Timesheet submitted successfully';
    });

    // ✅ CHANGED: Action: Update Timesheet with weekly data
   // ✅ UPDATED: Action: Update Timesheet with weekly data including daily task details
    this.on('updateTimesheet', async (req) => {
        const { timesheetID, weekData } = req.data;
        
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return 'Employee not found';
        
        const employeeID = employee.ID;

        const timesheet = await SELECT.one.from('my.timesheet.Timesheets')
            .where({ timesheetID, employee_ID: employeeID });

        if (!timesheet) {
            return req.error(404, 'Timesheet not found');
        }

        // Parse weekly data (expected as JSON string)
        let weeklyData;
        try {
            weeklyData = JSON.parse(weekData);
        } catch (e) {
            return req.error(400, 'Invalid weekly data format');
        }

        const updateData = {
            mondayHours: weeklyData.mondayHours || 0,
            tuesdayHours: weeklyData.tuesdayHours || 0,
            wednesdayHours: weeklyData.wednesdayHours || 0,
            thursdayHours: weeklyData.thursdayHours || 0,
            fridayHours: weeklyData.fridayHours || 0,
            saturdayHours: weeklyData.saturdayHours || 0,
            sundayHours: weeklyData.sundayHours || 0,
            
            // ✅ NEW: Include daily task details
            mondayTaskDetails: weeklyData.mondayTaskDetails || '',
            tuesdayTaskDetails: weeklyData.tuesdayTaskDetails || '',
            wednesdayTaskDetails: weeklyData.wednesdayTaskDetails || '',
            thursdayTaskDetails: weeklyData.thursdayTaskDetails || '',
            fridayTaskDetails: weeklyData.fridayTaskDetails || '',
            saturdayTaskDetails: weeklyData.saturdayTaskDetails || '',
            sundayTaskDetails: weeklyData.sundayTaskDetails || ''
        };

        // ✅ NEW: Update general task details if provided
        if (weeklyData.taskDetails) {
            updateData.taskDetails = weeklyData.taskDetails;
        }

        // ✅ NEW: Validate that hours and task details match
        const dailyValidations = [
            { day: 'Monday', hours: updateData.mondayHours, details: updateData.mondayTaskDetails },
            { day: 'Tuesday', hours: updateData.tuesdayHours, details: updateData.tuesdayTaskDetails },
            { day: 'Wednesday', hours: updateData.wednesdayHours, details: updateData.wednesdayTaskDetails },
            { day: 'Thursday', hours: updateData.thursdayHours, details: updateData.thursdayTaskDetails },
            { day: 'Friday', hours: updateData.fridayHours, details: updateData.fridayTaskDetails },
            { day: 'Saturday', hours: updateData.saturdayHours, details: updateData.saturdayTaskDetails },
            { day: 'Sunday', hours: updateData.sundayHours, details: updateData.sundayTaskDetails }
        ];

        for (const validation of dailyValidations) {
            if (validation.hours > 0 && (!validation.details || validation.details.trim() === '')) {
                return req.error(400, `${validation.day}: Task details are required when hours are entered.`);
            }
        }
        
        // Recalculate total
        updateData.totalWeekHours = 
            parseFloat(updateData.mondayHours) +
            parseFloat(updateData.tuesdayHours) +
            parseFloat(updateData.wednesdayHours) +
            parseFloat(updateData.thursdayHours) +
            parseFloat(updateData.fridayHours) +
            parseFloat(updateData.saturdayHours) +
            parseFloat(updateData.sundayHours);
        
        if (timesheet.status === 'Approved') {
            updateData.status = 'Modified';
        }

        await UPDATE('my.timesheet.Timesheets').set(updateData).where({ ID: timesheet.ID });

        return 'Timesheet updated successfully';
    });
    // Employee access validation
    this.before('READ', 'MyProfile', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) {
            req.reject(404, 'Employee not found');
        }
    });

    this.before('READ', 'MyTimesheets', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) {
            req.reject(404, 'Employee not found');
        }
    });

    this.before('READ', 'AvailableActivities', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) {
            req.reject(404, 'Employee not found');
        }
    });

    // AvailableTaskTypes Handler
    this.on('READ', 'AvailableTaskTypes', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return [];

        return [
            {
                code: 'Designing',
                name: 'Designing',
                description: 'UI/UX design, wireframing, mockups, prototyping',
                isProjectTask: true,
                icon: '🎨'
            },
            {
                code: 'Developing',
                name: 'Developing',
                description: 'Writing code, implementing features, building functionality',
                isProjectTask: true,
                icon: '💻'
            },
            {
                code: 'Testing',
                name: 'Testing',
                description: 'QA testing, test execution, test case creation',
                isProjectTask: true,
                icon: '🧪'
            },
            {
                code: 'Bug Fix',
                name: 'Bug Fix',
                description: 'Fixing defects, resolving issues, debugging',
                isProjectTask: true,
                icon: '🐛'
            },
            {
                code: 'Deployment',
                name: 'Deployment',
                description: 'Release activities, CI/CD, production releases',
                isProjectTask: true,
                icon: '🚀'
            },
            {
                code: 'Client Call',
                name: 'Client Call',
                description: 'Client meetings, stakeholder communication, demos',
                isProjectTask: true,
                icon: '📞'
            },
            {
                code: 'Leave',
                name: 'Leave',
                description: 'Time off, vacation, sick leave, personal days',
                isProjectTask: false,
                icon: '🏖️'
            }
        ];
    });

    // Before DELETE timesheet
    this.before('DELETE', 'MyTimesheets', async (req) => {
        const employee = await getAuthenticatedEmployee(req);
        if (!employee) return;

        const timesheet = await SELECT.one.from('my.timesheet.Timesheets').where({ ID: req.data.ID });
        
        if (!timesheet) {
            return req.error(404, 'Timesheet not found');
        }

        if (timesheet.employee_ID !== employee.ID) {
            return req.error(403, 'You can only delete your own timesheets');
        }
        
        if (timesheet.status === 'Approved') {
            return req.error(400, 'Cannot delete approved timesheets');
        }
    });
});