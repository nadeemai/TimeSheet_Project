sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/core/BusyIndicator"
], function(Controller, MessageToast, MessageBox, BusyIndicator) {
    "use strict";

    return Controller.extend("employee.controller.OTPVerification", {
        onInit: function() {
            // Get encrypted ID from route parameters
            const oRoute = this.getOwnerComponent().getRouter().getRoute("otp-verification");
            oRoute.attachPatternMatched(this._onRouteMatched, this);
        },
        
        _onRouteMatched: function(oEvent) {
            const oArguments = oEvent.getParameter("arguments");
            this._sEncryptedId = oArguments.encryptedId;
            
            // Reset UI
            this.byId("otpInput").setValue("");
            this.byId("verifyButton").setEnabled(false);
            this.byId("messageText").setText("");
        },
        
        onOTPChange: function(oEvent) {
            const sValue = oEvent.getParameter("value");
            const bValid = sValue.length === 6;
            this.byId("verifyButton").setEnabled(bValid);
        },
        
        onVerifyOTP: function() {
            const sOTP = this.byId("otpInput").getValue();
            
            if (sOTP.length !== 6) {
                MessageBox.error("Please enter a valid 6-digit OTP");
                return;
            }
            
            BusyIndicator.show(0);
            
            // Simulate OTP verification (replace with actual service call)
            setTimeout(() => {
                BusyIndicator.hide();
                
                // For demo, accept any 6-digit OTP
                if (sOTP.length === 6) {
                    // Set user as authenticated
                    this._setUserAuthenticated();
                    
                    // Navigate to employee dashboard
                    this.getOwnerComponent().getRouter().navTo("employee", {}, true);
                } else {
                    MessageBox.error("Invalid OTP. Please try again.");
                }
            }, 1000);
        },
        
        onResendOTP: function() {
            BusyIndicator.show(0);
            
            // Simulate OTP resend (replace with actual service call)
            setTimeout(() => {
                BusyIndicator.hide();
                MessageToast.show("OTP has been resent to your registered email/phone");
            }, 1000);
        },
        
        _setUserAuthenticated: function() {
            // Set user model (replace with actual user data)
            const oUserModel = new sap.ui.model.json.JSONModel({
                id: "EMP123",
                name: "John Doe",
                email: "john.doe@example.com",
                authenticated: true
            });
            this.getOwnerComponent().setModel(oUserModel, "currentUser");
        }
    });
});